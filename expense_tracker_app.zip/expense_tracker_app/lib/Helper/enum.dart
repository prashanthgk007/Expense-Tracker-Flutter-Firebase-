


enum ChartType { pie, bar, area }
enum ExpenseBasis { daily, monthly, weekly }
enum ExpenseCategory { food, travel, shopping, bills, other }