package com.example.expense_tracker_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
